<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
</head>
<body>
<?php
  require_once('dbconnection.php');

  if(isset($_POST['submitSubcriptions'])){
    // 2 fetch from data
    $email=$_POST["email"];
    //3. SQL Query to insert data to database
    $queryData=mysqli_query($conn,"INSERT INTO subscribers (email) VALUES('$email')");
    //4.check if data inserted
    if($queryData){
        echo "Data submitted successfully";
    }
    else{
        echo "Error";
    }
    }
?>
    <nav class="navbar navbar-expand-lg bg-transparent">
        <div class="container-fluid">
          <a class="navbar-brand" href="#">Zalego Academy</a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0 ms-auto">
                <li class="nav-item">
                    <a class="nav-link" href="#">Home</a>
                  </li>
              <li class="nav-item">
                <a class="nav-link active" aria-current="page" href="#">About us</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#"><button class="btn btn-warning register">Register Now</button></a>
              </li>
            </ul>
          </div>
        </div>
      </nav>
    <section class="container-fluid bg-warning" >
        <div class="container about-us ">
            <h2>About Us</h2>
            <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Nemo doloribus possimus, beatae iusto dicta molestiae repellendus dolore incidunt eius neque magnam mollitia ipsum expedita? Distinctio sint fugit veniam tempore eos maiores molestias tempora exercitationem. Commodi ad earum neque perspiciatis consectetur, et ratione eius vel officia? Sapiente laboriosam distinctio optio atque.</p>
        </div>
    </section>  

    <section class="container">
        <div class="row">
            <div class="col-lg-6">
                <h2>Our program</h2>
                <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Labore eos vitae repellat distinctio? Vel sed alias laboriosam atque ea necessitatibus sequi sint, tenetur ad quasi dolore nemo at architecto? Aliquid quam laudantium tempore quod id itaque asperiores dicta vel nobis porro natus adipisci, amet ad nostrum accusamus magnam rerum. Consectetur eveniet deserunt cumque ratione impedit earum corporis harum magni, at quam, cupiditate tempore. Tempore voluptatem natus magnam dolorem officia, odio quaerat perspiciatis similique consectetur libero, mollitia nemo maxime possimus a!</p>

            </div>
            <div class="col-lg-6">
                <img src="Laptops.jpg" alt="image" class="container">
            </div>
        </div>
    </section>
    <div class="container">
        <h2>The Programs</h2>
    </div>

    <section class="container programs">
        <div class="row">
        <div class="col-lg-4">
            <div class="card" style="width: 18rem;">
                <div class="card-body">
                  <h5 class="card-title">Skill Discovery</h5>
                  <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                  <a href="#" class="btn btn-warning">View Details</a>
                </div>
              </div>

        </div>
        <div class="col-lg-4">
            <div class="card" style="width: 18rem;">
                <div class="card-body">
                  <h5 class="card-title">Upskilling Program</h5>
                  <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                  <a href="#" class="btn btn-warning">View Details</a>
                </div>
              </div>

        </div>
        <div class="col-lg-4">
            <div class="card" style="width: 18rem;">
                <div class="card-body">
                  <h5 class="card-title">Pathfinding</h5>
                  <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                  <a href="#" class="btn btn-warning">View Details</a>
                </div>
              </div>

        </div>
        </div>
    </section>
    <div class="container subcribe">
        <p>Subscribe to get information, latest news about Zalego Academy</p>
    </div>
    <section class="container">
      <form action="index.php" method="post">
        <div class="row">
            <div class="col-lg-7">
                <div class="form-group ">
                    <input type="email" class="form-control" id=""  placeholder="Your email address" name="email">
                  </div>
            </div>
            <div class="col-lg-5">
                <button class="btn btn-warning" name="submitSubcriptions" type="submit">Subscribe</button>
            </div>
        </div>
       </form>
       
    </section>
    <div class="container">
        <hr>
    </div>

    <div class="container copyright">
        <p class="navbar-text">© Zalego2022</p>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>  
</body>
</html>